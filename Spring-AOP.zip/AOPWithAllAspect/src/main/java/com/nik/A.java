package com.nik;

public class A {
	public  void test(){
		int i =90/0; 
	}
}
