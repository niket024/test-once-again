package com.nik;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Manager
{
	public static void main(String[] args)
	{
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(
				"config.xml");
		Product product = (Product) context.getBean("p1");
		System.out.println(product);
		/*System.out.println(product.getId());
		System.out.println(product.getName());
		System.out.println(product.getPrice());
		System.out.println(product.getDesc());
		System.out.println("done");*/
		context.close();
	}
}
