H2 Databse will be accessible by
----------------------------
JDBC URL : jdbc:h2:mem:testdb
http://localhost:8090/h2-console/

@JsonIgnoreProperties
-------------------
@JsonIgnoreProperties ignores the specified logical properties in JSON serialization and deserialization.
 It is annotated at class level. Find the code snippet.