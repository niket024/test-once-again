package com.nik;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class Manager1
{
	private static ApplicationContext context;

	public static void main(String[] args)
	{
		context = new ClassPathXmlApplicationContext(
				"config.xml");
		Person p1 = (Person) context.getBean("p1");
		Person p2= (Person) context.getBean("p1");
		System.out.println(p1 == p2);
	

		
	}
}
