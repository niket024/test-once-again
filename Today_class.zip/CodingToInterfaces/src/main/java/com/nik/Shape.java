package com.nik;

public interface Shape
{
	void draw();
}
