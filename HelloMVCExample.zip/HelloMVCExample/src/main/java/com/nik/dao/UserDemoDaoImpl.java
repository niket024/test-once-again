package com.nik.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.nik.model.UserDemo;

@Repository("userDemoDao")
public class UserDemoDaoImpl implements UserDemoDao {
	@Autowired
	private SessionFactory sessionFactory;

	public UserDemoDaoImpl(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Override
	@Transactional
	public void saveUser(UserDemo userDemo) {
		Session session = sessionFactory.getCurrentSession();
		session.save(userDemo);
	}

	@Override
	@Transactional
	public boolean validateUser(String uname, String pwd) {
		String sql = "from UserDemo where username = ? and password = ?";
		Session session = sessionFactory.getCurrentSession();
		@SuppressWarnings({ "deprecation", "unchecked" })
		List<UserDemo> user = session.createQuery(sql).setParameter(0, uname)
				.setParameter(1, pwd).list();
		if (user.size() > 0) {
			System.out.println("uname = " + user.get(0).getUserName());
			return true;
		} else {
			return false;
		}

	}
}
