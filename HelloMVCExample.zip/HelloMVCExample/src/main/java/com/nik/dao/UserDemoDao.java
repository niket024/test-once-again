package com.nik.dao;

import com.nik.model.UserDemo;

public interface UserDemoDao {

	void saveUser(UserDemo userDemo);

	boolean validateUser(String uname, String pwd);
}
