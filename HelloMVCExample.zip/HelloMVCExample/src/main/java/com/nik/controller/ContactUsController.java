package com.nik.controller;



import java.util.Random;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.nik.dao.ContactUsDao;
import com.nik.model.ContactUs;

@Controller
public class ContactUsController {
	@Autowired(required = true)
	private ContactUsDao contactUsDao;
	@RequestMapping("/submitEnquiery")
	public String regFormSubmit(HttpServletRequest req, HttpServletResponse res) {
		String name = req.getParameter("name");
		String email = req.getParameter("email");
		String subject = req.getParameter("subject");
		String message = req.getParameter("message");
		Random rand = new Random();
		ContactUs contactUs = new ContactUs();
		contactUs.setMsgId(rand.nextInt(50) + 1);
		contactUs.setName(name);
		contactUs.setEmail(email);
		contactUs.setMessage(message);
		contactUs.setSubject(subject);
		contactUsDao.saveEnquiery(contactUs);
		return "index";
	}

}
