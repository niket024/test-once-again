package com.pack2;

public class C extends B
{

}
