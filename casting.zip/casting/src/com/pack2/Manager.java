package com.pack2;

public class Manager
{
    static int test()
    {
    	double d=90.34;
    	return (int)d;
    }
    public static void main(String[] args)
	{
		test();
	}
}
