package com.pack2;

public class AutoUpcasting
{
	public static void main(String[] args)
	{
		A a1 = new A();
		A a2 = new B();
		A a3 = new C();
		A a4 = new D();
		B b1 = new B();
		B b2 = new C();
		B b3 = new D();
		C c1 = new C();
		C c2 = new D();
		Object obj=new  A();
		System.out.println("done");
	}
}
